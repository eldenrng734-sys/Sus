# SYNTRIX Product Showcase

A 12-slide, 16:9 cinematic product deck built with Reveal.js. It runs entirely
from local files: no CDN, no build step, no network access required.

## Open and present

**Recommended — local server**

From the repository root:

```powershell
python -m http.server 4173 --bind 127.0.0.1
```

Then open <http://127.0.0.1:4173/presentation/>.

You can also double-click `presentation/index.html`. The deck was tested from
`file://` in Chromium and loads its fonts, images and notes correctly.

### Controls

| Key | Action |
| --- | --- |
| `→` / `Space` / click | Next slide or fragment |
| `←` | Previous slide or fragment |
| `F` | Enter / exit fullscreen |
| `S` | Open speaker view (presenter notes, timer, next slide) |
| `O` / `Esc` | Slide overview |
| `?` | Reveal.js help |

The **FULLSCREEN** button in the bottom-right corner does the same as `F`.
Every slide has presenter notes. Speaker view opens a popup, so allow popups
for the page if your browser blocks it.

## Slides

1. Cover — The future of intelligent sales
2. The problem — Interest arrives in fragments
3. The solution — One connected surface
4. Product overview — Capture → Assess → Assign → Follow up → Close
5. Lead capture — WhatsApp, Meta, web form, CSV/manual
6. AI intelligence — Advisory assessment with human review
7. Sales automation — Ownership, tasks, approvals, quiet hours, consent
8. Conversations — WhatsApp and Messenger in one inbox
9. Dashboard — Role-aware pipeline visibility
10. Architecture — Multi-tenant, implementation-aligned overview
11. Workspace tour — Leads, tasks and dashboard screens
12. Closing

## PDF

`SYNTRIX-Product-Showcase.pdf` is a 12-page, 13.333 × 7.5 in (16:9) export.
It is generated from the same deck in static mode.

Regenerate it with:

```powershell
cd presentation
node tools/export-pdf.js
```

The script uses Playwright from `presentation/node_modules` if present, then
falls back to `../frontend/node_modules/playwright`. It captures each slide at
2× scale as JPEG and writes both the PDF and intermediate images to
`presentation/.export/`.

For deterministic screenshots without generating a PDF, open:

```text
index.html?static=1
```

Static mode shows all fragments, removes per-slide transitions and disables
decorative animation. `?print=1` behaves the same way.

## Structure

```text
presentation/
  index.html                 12 slides, icon sprite, presenter notes
  styles.css                 design system and slide compositions
  deck.js                    Reveal config, counters, parallax, fullscreen
  assets/
    screens/                 actual product screenshots
    fonts/                   local Sora + Inter woff2 files
    syntrix-brand-dark.svg   light-text logo for slide topbars
    syntrix-mark.svg         gradient S mark
  vendor/reveal.js/          local Reveal.js 5.2.1 runtime + notes plugin
  tools/export-pdf.js        static capture → PDF
  SYNTRIX-Product-Showcase.pdf
  README.md
```

The design coordinate system is 1920 × 1080. Reveal.js scales the whole stage
to the viewport, so slide layouts stay proportional at any window size.

## Content notes

- Every product screen is a real screenshot of the running SYNTRIX workspace.
- All names, leads, tasks and numbers in the screenshots are synthetic demo
  data. Dashboard values (48 new leads, 12 due today, 10.0% conversion) are
  labeled as sample data in the deck and are not customer results.
- The AI console is an illustrative example using a synthetic inquiry. The
  fields shown — intent, sentiment, priority, lead score, summary, recommended
  action, confidence and human review — correspond to implemented assessment
  output.
- The architecture slide is a conceptual, implementation-aligned overview, not
  a deployment diagram or a compliance certification.
- Channel claims are limited to what the build supports: WhatsApp Business,
  Meta Lead Ads, Messenger, public lead forms, CSV import and manual entry.

## Editing

- Slide markup and notes: `index.html` (`<section class="slide …">`).
- Colors, type, spacing and per-slide layouts: `styles.css`.
- Timing, counters and presentation behavior: `deck.js`.
- Replace a screenshot by dropping a new image into `assets/screens/` and
  updating the matching `<img src="…">`. Keep the 16:10-ish browser aspect
  ratio for the framed screens.
- When adding or removing slides, update the footer index (`NN / 12`), the
  kicker number, and the total in `README.md`. The PDF export reads the slide
  count from Reveal automatically.
