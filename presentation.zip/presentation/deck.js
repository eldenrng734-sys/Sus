/* SYNTRIX deck runtime — Reveal.js configuration, motion, counters, export mode. */
(function () {
  "use strict";

  var params = new URLSearchParams(window.location.search);
  var isStatic = params.get("static") === "1" || params.get("print") === "1";
  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  if (isStatic) {
    document.documentElement.classList.add("static");
    /* Per-slide transitions (slide/zoom) would otherwise override the static
       "none" transition and shift captures mid-animation. */
    document.querySelectorAll("[data-transition]").forEach(function (el) {
      el.removeAttribute("data-transition");
    });
  }

  var plugins = [];
  if (typeof RevealNotes !== "undefined") {
    plugins.push(RevealNotes);
  }

  Reveal.initialize({
    width: 1920,
    height: 1080,
    margin: 0,
    minScale: 0.2,
    maxScale: 2,
    center: false,
    hash: !isStatic,
    history: !isStatic,
    respondToHashChanges: !isStatic,
    controls: false,
    progress: !isStatic,
    slideNumber: false,
    keyboard: true,
    overview: true,
    touch: true,
    loop: false,
    shuffle: false,
    fragments: !isStatic,
    fragmentInURL: false,
    embedded: false,
    help: true,
    transition: isStatic ? "none" : "fade",
    transitionSpeed: "default",
    backgroundTransition: isStatic ? "none" : "fade",
    viewDistance: 3,
    mobileViewDistance: 2,
    plugins: plugins
  }).then(function () {
    document.documentElement.classList.add("deck-ready");
    animateCounters(Reveal.getCurrentSlide());
  });

  Reveal.on("slidechanged", function (event) {
    animateCounters(event.currentSlide);
  });

  /* Animated statistics — only elements that carry real values. */
  function animateCounters(slide) {
    if (!slide) return;
    var nodes = slide.querySelectorAll("[data-count]");
    if (!nodes.length) return;

    nodes.forEach(function (el) {
      var target = parseFloat(el.getAttribute("data-count"));
      if (isNaN(target)) return;
      var decimals = parseInt(el.getAttribute("data-decimals") || "0", 10);
      var suffix = el.getAttribute("data-suffix") || "";
      var prefix = el.getAttribute("data-prefix") || "";

      if (isStatic || reduceMotion) {
        el.textContent = prefix + target.toFixed(decimals) + suffix;
        return;
      }

      var duration = 1200;
      var started = null;
      el.textContent = prefix + (0).toFixed(decimals) + suffix;

      function frame(now) {
        if (started === null) started = now;
        var progress = Math.min(1, (now - started) / duration);
        var eased = 1 - Math.pow(1 - progress, 3);
        el.textContent = prefix + (target * eased).toFixed(decimals) + suffix;
        if (progress < 1) {
          window.requestAnimationFrame(frame);
        } else {
          el.textContent = prefix + target.toFixed(decimals) + suffix;
        }
      }
      window.requestAnimationFrame(frame);
    });
  }

  /* Subtle pointer parallax for cinematic depth. */
  var parallaxNodes = Array.prototype.slice.call(document.querySelectorAll(".parallax"));
  if (parallaxNodes.length && !reduceMotion && !isStatic) {
    var pointerX = 0;
    var pointerY = 0;
    var raf = null;

    function applyParallax() {
      raf = null;
      parallaxNodes.forEach(function (node) {
        var depth = parseFloat(node.getAttribute("data-parallax") || "8");
        node.style.setProperty("--px", (pointerX * depth).toFixed(2) + "px");
        node.style.setProperty("--py", (pointerY * depth).toFixed(2) + "px");
      });
    }

    window.addEventListener("mousemove", function (event) {
      pointerX = (event.clientX / window.innerWidth - 0.5) * 2;
      pointerY = (event.clientY / window.innerHeight - 0.5) * 2;
      if (raf === null) raf = window.requestAnimationFrame(applyParallax);
    }, { passive: true });
  }

  /* Fullscreen control. Reveal already maps the F key. */
  var fsButton = document.querySelector(".fullscreen-btn");
  if (fsButton) {
    fsButton.addEventListener("click", function () {
      if (document.fullscreenElement) {
        document.exitFullscreen();
      } else if (document.documentElement.requestFullscreen) {
        document.documentElement.requestFullscreen();
      }
    });
    document.addEventListener("fullscreenchange", function () {
      var active = Boolean(document.fullscreenElement);
      fsButton.setAttribute("aria-pressed", String(active));
      var label = fsButton.querySelector("span");
      if (label) label.textContent = active ? "EXIT FULLSCREEN" : "FULLSCREEN";
    });
  }
})();
