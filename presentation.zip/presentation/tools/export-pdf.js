/*
 * Export the 12-slide deck to a 16:9 PDF.
 *
 * Usage (from the presentation folder):
 *   node tools/export-pdf.js
 *
 * The script captures every slide in static mode (all fragments visible,
 * transitions and decorative animation disabled), then assembles the PNGs
 * into a 13.333in × 7.5in PDF. It loads Playwright from the project's
 * frontend node_modules if it is not installed locally.
 */

const fs = require("fs");
const path = require("path");
const { pathToFileURL } = require("url");

const root = path.resolve(__dirname, "..");

let chromium;
try {
  ({ chromium } = require("playwright"));
} catch (error) {
  ({ chromium } = require(path.join(root, "..", "frontend", "node_modules", "playwright")));
}

const exportDir = path.join(root, ".export");
const pdfPath = path.join(root, "SYNTRIX-Product-Showcase.pdf");
const deckUrl = pathToFileURL(path.join(root, "index.html")).href + "?static=1";

async function main() {
  fs.rmSync(exportDir, { recursive: true, force: true });
  fs.mkdirSync(exportDir, { recursive: true });

  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({
    viewport: { width: 1920, height: 1080 },
    deviceScaleFactor: 2
  });

  await page.goto(deckUrl, { waitUntil: "networkidle" });
  await page.evaluate(() => document.fonts.ready);
  await page.waitForFunction(() => document.documentElement.classList.contains("deck-ready"), {
    timeout: 15000
  });
  await page.waitForTimeout(500);

  const total = await page.evaluate(() => Reveal.getTotalSlides());
  const captures = [];

  for (let i = 0; i < total; i += 1) {
    await page.evaluate((index) => Reveal.slide(index, 0, 0), i);
    await page.waitForTimeout(250);
    const file = path.join(exportDir, "slide-" + String(i + 1).padStart(2, "0") + ".jpg");
    await page.screenshot({ path: file, type: "jpeg", quality: 90, animations: "disabled" });
    captures.push(file);
    process.stdout.write("captured slide " + (i + 1) + "/" + total + "\n");
  }

  const sections = captures
    .map((file) => '    <section><img src="' + pathToFileURL(file).href + '" alt=""></section>')
    .join("\n");

  const printHtml = [
    "<!DOCTYPE html>",
    '<html lang="en">',
    "<head>",
    '  <meta charset="utf-8">',
    "  <title>SYNTRIX Product Showcase — PDF</title>",
    "  <style>",
    "    @page { size: 13.333in 7.5in; margin: 0; }",
    "    html, body { margin: 0; padding: 0; background: #04060d; }",
    "    section { width: 13.333in; height: 7.5in; overflow: hidden; page-break-after: always; break-after: page; }",
    "    section:last-child { page-break-after: auto; break-after: auto; }",
    "    img { display: block; width: 100%; height: 100%; object-fit: cover; }",
    "  </style>",
    "</head>",
    "<body>",
    sections,
    "</body>",
    "</html>"
  ].join("\n");

  const printPath = path.join(exportDir, "print.html");
  fs.writeFileSync(printPath, printHtml, "utf8");

  const printPage = await browser.newPage();
  await printPage.goto(pathToFileURL(printPath).href, { waitUntil: "networkidle" });
  await printPage.pdf({
    path: pdfPath,
    width: "13.333in",
    height: "7.5in",
    printBackground: true,
    preferCSSPageSize: true,
    margin: { top: "0", right: "0", bottom: "0", left: "0" }
  });

  await browser.close();

  const size = fs.statSync(pdfPath).size;
  console.log("PDF: " + pdfPath);
  console.log("Size: " + (size / (1024 * 1024)).toFixed(1) + " MB");
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
